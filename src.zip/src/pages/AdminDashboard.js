function AdminDashboard() {
  const handleLogout = () => {
    localStorage.removeItem("role");
    window.location.href = "/";
  };

  return (
    <div style={{ padding: "40px", fontFamily: "Segoe UI" }}>
      <h1>Admin Dashboard</h1>
      <p>Manage users and api's here.</p>

      <div style={{ marginTop: "30px" }}>
        <button
          onClick={handleLogout}
          style={{
            padding: "10px 20px",
            background: "#2575fc",
            color: "white",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          Logout
        </button>
      </div>
    </div>
  );
}

export default AdminDashboard;
