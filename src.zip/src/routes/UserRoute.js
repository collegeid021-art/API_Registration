import { Navigate } from "react-router-dom";

const UserRoute = ({ children }) => {
  const role = localStorage.getItem("role");
  return role === "USER" ? children : <Navigate to="/" />;
};

export default UserRoute;
